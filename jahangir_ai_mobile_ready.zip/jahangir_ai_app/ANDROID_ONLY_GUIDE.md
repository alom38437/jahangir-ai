# Jahangir AI — Android-only setup guide

You can do both publishing and APK building from an Android phone using Chrome and GitHub's website. No laptop is required for the cloud build.

## A. Upload the project to GitHub
1. Download and extract `jahangir_ai_mobile_ready.zip` using Files / My Files.
2. In Chrome, open https://github.com and sign in or create an account.
3. Create a new repository named `jahangir-ai`. Choose Public (easiest for GitHub Pages) and create it.
4. Open the new repository. Use **Add file → Upload files**.
5. Upload the contents inside the `jahangir_ai_app` folder (not the outer folder itself), including:
   - `.github` folder and both workflow files inside it
   - `web` folder
   - `android` folder
   - `README.txt`
   Commit the upload to the main branch.
   Note: if GitHub's mobile upload interface hides dot-folders, create `.github/workflows` in the repository using Add file → Create new file and add the workflow file contents from the ZIP. The two workflow files are `android-apk.yml` and `web-pages.yml`.

## B. Publish the Web App
1. In your repository, open **Actions**.
2. If GitHub asks, enable Actions.
3. Open workflow **Publish Jahangir AI Web App** and tap **Run workflow**.
4. Wait for the green check mark.
5. Open **Settings → Pages** to find the published website URL.
6. Open that URL in Chrome on Android. Use Chrome menu ⋮ → **Add to Home screen** or **Install app**.

## C. Build Android APK on GitHub
1. Open **Actions**.
2. Choose **Build Jahangir AI Android APK**.
3. Tap **Run workflow**.
4. Wait for the workflow to finish with a green check.
5. Open the completed workflow run, scroll to **Artifacts**, and download `jahangir-ai-debug-apk`.
6. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.
7. Tap `app-debug.apk` to install. Android may ask permission to install unknown apps for Chrome or Files. Only install the APK you built from your own repository.

## Important notes
- The Web App needs internet access to fetch Delta Exchange's public ticker. If the browser shows a CORS/network error, the exchange endpoint is blocking direct browser requests; the app then needs a small server-side proxy before the Web App can work. Do not put exchange secrets in browser code.
- The Android WebView app calls the same public endpoint. If it returns a network error, check internet access and the Delta endpoint.
- This is an experimental momentum indicator, not a trained AI prediction model. UP/DOWN labels are not guaranteed forecasts. Accuracy is a small-sample paper-test metric; it excludes WAIT and flat outcomes and does not include fees, spread, slippage, or execution.
- No automatic trading or order placement is included.
